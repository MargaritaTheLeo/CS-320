/*                                             *
 * CS-320-R4843 Software Test Automation & QA  *
 * Professor: Angelo Luo                       *
 * Student: Margarita Kiseleva                 *
 * Assignment: 6-1 Project                     *
 * Date: 4/10/2024                             *
 */

// Importing necessary packages and libraries
package main;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

//Declaring a public class task service
public class TaskService {
	
	//	Creating a private hash map to hold a list of tasks
	private Map<String, Task> tasks = new HashMap<>();
	
	//	Creating a public method for adding a new task to the list
	public void addTask(Task task) throws CloneNotSupportedException {
		//	Checking whether a task with the same ID already exists in the list
		if(tasks.get(task.getTaskID()) != null) {
			// If it already exists, throwing an exception
			throw new CloneNotSupportedException("Warning! This task already exists.");	
		}
		// If the task is indeed new, adding it to the list
		tasks.put(task.getTaskID(), task);
	}
	
	//	Creating a public method for removing a task from the list
	public void removeTask(String taskID) {
		tasks.remove(taskID);
	}
	
	//	Creating a public method for updating the task name
	public void updateTaskName(String taskID, String taskName) {
		//	Getting an instance of a task from the list
		Task task = tasks.get(taskID);
		// If the task ID is not null
		if (task != null) {
			// Proceed to updating the task name
			task.updateTaskName(taskName);
		}
		// If the task ID is null, throwing an exception
		else {
			throw new NoSuchElementException();	
		}
	}
	
	//	Creating a public method for updating the task description
	public void updateTaskDescription(String taskID, String taskDescription) {
		// Getting an instance of a task from the list
		Task task = tasks.get(taskID);
		// If the task ID is not null
		if (task != null) {
			// Proceed to updating the task description
			task.updateTaskDescription(taskDescription);	
		}
		// If the task ID is null, throwing an exception
		else {
			throw new NoSuchElementException();	
		}
	}
	
	//	Creating a public method for getting and returning a task
	public Task getTask(String taskID) {
		return tasks.get(taskID);		
	}
}
