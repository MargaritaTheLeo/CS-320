/*                                             *
 * CS-320-R4843 Software Test Automation & QA  *
 * Professor: Angelo Luo                       *
 * Student: Margarita Kiseleva                 *
 * Assignment: 6-1 Project                     *
 * Date: 4/10/2024                             *
 */

//Importing necessary packages and libraries
package main;

import java.util.HashMap;
import java.util.Date;

public class AppointmentService {

	// Setting a unique appointment identifier to be equal zero
	int currentIDNum = 0;
	
	// Creating a hash map to store a list of appointments
	public static HashMap<String, Appointment> appointments = new HashMap<String, Appointment>();
	
	// Creating a method for adding a unique appointment to the list
	public void addUniqueAppointment(Date appointmentDate, String appointmentDescription) {
		String appointmentID = Integer.toString(currentIDNum);		
		Appointment tempAppointment = new Appointment (appointmentID, appointmentDate, appointmentDescription);
		appointments.put(appointmentID, tempAppointment);	
		// Augmenting the unique ID by one
		++currentIDNum;		
	}
	
	// Creating a method for removing an appointment from the list
	public void deleteAppointment(String appointmentID) {
		if(appointments.containsKey(appointmentID)) {			
			appointments.remove(appointmentID);
		}		
	}
	
	// Creating a method for updating an existing appointment
	public void updateAppointment(String appointmentID, Date appointmentDate, String appointmentDescription) {
		if(appointments.containsKey(appointmentID)) {
			appointments.get(appointmentID).setAppointmentDate(appointmentDate);
			appointments.get(appointmentID).setAppointmentDescription(appointmentDescription); 
		} 
	}
}
