/*                                             *
 * CS-320-R4843 Software Test Automation & QA  *
 * Professor: Angelo Luo                       *
 * Student: Margarita Kiseleva                 *
 * Assignment: 6-1 Project                     *
 * Date: 4/10/2024                             *
 */

// Importing necessary packages and libraries
package main;

//Importing needed package
import java.util.*;

//Declaring a public class ContactService
public class ContactService {
	
	//	Creating a private hash map to hold a list of contacts
	private Map<String, Contact> contacts = new HashMap<>();
	
	//	Creating a public method for adding a new contact to the list
	public void addContact(Contact contact) throws CloneNotSupportedException {
		//	Checking whether a contact with the same ID already exists in the list
		if(contacts.get(contact.getContactID()) != null) {
			// If it already exists, throwing an exception
			throw new CloneNotSupportedException("Warning! This contact ID already exists.");	
		}
		// If the contact is indeed new, adding it to the list
		contacts.put(contact.getContactID(), contact);
	}
	
	//	Creating a public method for removing a contact from the list
	public void removeContact(String contactID) {
		contacts.remove(contactID);
	}
	
	//	Creating a public method for updating the first name
	public void updateFirstName(String contactID, String firstName) {
		//	Getting an instance of a contact from the list
		Contact contact = contacts.get(contactID);
		// If the contact ID is not null
		if (contact != null) {
			// Proceed to updating the first name
			contact.updateFirstName(firstName);
		}
		// If the contact ID is null, throwing an exception
		else {
			throw new NoSuchElementException();	
		}
	}
	
	//	Creating a public method for updating the last name
	public void updateLastName(String contactID, String lastName) {
		// Getting an instance of a contact from the list
		Contact contact = contacts.get(contactID);
		// If the contact ID is not null
		if (contact != null) {
			// Proceed to updating the last name
			contact.updateLastName(lastName);	
		}
		// If the contact ID is null, throwing an exception
		else {
			throw new NoSuchElementException();	
		}
	}

	//	Creating a public method for updating the phone number
	public void updatePhoneNumber(String contactID, String phoneNumber) {
		//	Getting an instance of a contact from the list
		Contact contact = contacts.get(contactID);
		// If the contact ID is not null
		if (contact != null) {
			// Proceed to updating the phone number
			contact.updatePhoneNumber(phoneNumber);
		}
		// If the contact ID is null, throwing an exception
		else {
			throw new NoSuchElementException();
		}
	}

	//	Creating a public method for updating the address
	public void updateAddress(String contactID, String address) {
		// Getting an instance of a contact from the list
		Contact contact = contacts.get(contactID);
		// If the contact ID is not null
		if (contact != null) {
			// Proceed to updating the address
			contact.updateAddress(address);
		}
		// If the contact ID is null, throwing an exception
		else {
			throw new NoSuchElementException();
		}
	}
	
	//	Creating a public method for getting and returning a contact
	public Contact getContact(String contactID) {
		return contacts.get(contactID);		
	}
	
}
