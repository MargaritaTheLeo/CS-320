/*                                             *
 * CS-320-R4843 Software Test Automation & QA  *
 * Professor: Angelo Luo                       *
 * Student: Margarita Kiseleva                 *
 * Assignment: 6-1 Project                     *
 * Date: 4/10/2024                             *
 */

// Importing necessary packages and libraries
package main;

//Declaring a public class named Contact 
public class Contact {
	// Setting Contact class variables to be private
 private String contactID;
 private String firstName;
 private String lastName;
 private String phoneNumber;
 private String address;

 // Creating Contact class private setter function for the contact's ID
	private boolean setContactID(String contactID) {
		//	Throwing exception if the contactID is either null or longer than 10 characters
		if(contactID == null || contactID.length() > 10) {
			throw new IllegalArgumentException("Invalid input! ID must be between 1 and 10 characters long.");
		}
		this.contactID = contactID;
		return true;
	}
	
	// Creating Contact class public setter function for the contact's first name
	public boolean setFirstName(String firstName) {
		// Throwing exception if the first name is either null or longer than 10 characters
		if(firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid input! First name must be between 1 and 10 characters long.");
		}
		this.firstName = firstName;
		return true;
	}
	
	// Creating Contact class public setter function for the contact's last name
	public boolean setLastName(String lastName) {
		//	Throwing exception if the last name is either null or longer than 10 characters
		if(lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid input! Last name must be between 1 and 10 characters long.");	
		}
		this.lastName = lastName;
		return true;
	}
	
	// Creating Contact class public setter function for the contact's phone number
	public boolean setPhoneNumber(String phoneNumber) {
		//	Throwing exception if the phone number is not exactly 10 characters long
		if(phoneNumber == null || phoneNumber.length() != 10) {
			throw new IllegalArgumentException("Invalid input! Phone number must be exactly 10 characters long.");
		}
		this.phoneNumber = phoneNumber;
		return true;
	}
	
	// Creating Contact class public setter function for the contact's address
	public boolean setAddress(String address) {
		//	Throwing exception if the address is either null or longer than 30 characters
			if(address == null || address.length() > 30) {
				throw new IllegalArgumentException("Invalid input! Address must be between 1 and 30 characters long.");	
			}
			this.address = address;
			return true;
	}
	
	//	Creating a private ID constructor to be used in the future
	@SuppressWarnings("unused")
	private Contact(String contactID) {
		//	Setting the contact ID		
		setContactID(contactID);	
	}
	
	//	Creating a public Contact constructor
	public Contact(String contactID, String firstName, String lastName, String phoneNumber, String address) {
		//	Setting Contact class values
		setContactID(contactID);
		setFirstName(firstName);
		setLastName(lastName);
		setPhoneNumber(phoneNumber);
		setAddress(address);	
	}
	
	//	Creating a public first name getter function for the Contact class
	public String getFirstName() {
		return this.firstName;
	}
	
 //	Creating a public last name getter function for the Contact class
	public String getLastName() {
		return this.lastName;	
	}
	
 //	Creating a public phone number getter function for the Contact class
	public String getPhoneNumber() {
		return this.phoneNumber;
	}
	
 //	Creating a public address getter function for the Contact class
	public String getAddress() {	
		return this.address;
	}
	
 //	Creating a public ID getter function for the Contact class
	public String getContactID() {
		return this.contactID;
	}
	
	//	Creating public first name update function (setter) for the Contact class
	public void updateFirstName(String firstName) {
		setFirstName(firstName);
	}
	
 //	Creating public last name update function (setter) for the Contact class
	public void updateLastName(String lastName) {
		setLastName(lastName);
	}
	
 //	Creating public phone number update function (setter) for the Contact class
	public void updatePhoneNumber(String phoneNumber) {
		setPhoneNumber(phoneNumber);
	}
	
 //	Creating public address update function (setter) for the Contact class
	public void updateAddress(String address) {
		setAddress(address);
	}
	
}

