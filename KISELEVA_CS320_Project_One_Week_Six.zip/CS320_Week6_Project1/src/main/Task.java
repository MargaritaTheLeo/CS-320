/*                                             *
 * CS-320-R4843 Software Test Automation & QA  *
 * Professor: Angelo Luo                       *
 * Student: Margarita Kiseleva                 *
 * Assignment: 6-1 Project                     *
 * Date: 4/10/2024                             *
 */

// Importing necessary packages and libraries
package main;

//Declaring a public class named Task 
public class Task {
	// Setting Task class variables to be private
	private String taskID;
	private String taskName;
	private String taskDescription;

  // Creating Task class private setter function for the task ID
	private boolean setTaskID(String taskID) {
		//	Throwing exception if the task ID is either null or longer than 10 characters
		if(taskID == null || taskID.length() > 10) {
			throw new IllegalArgumentException("Invalid input! Task ID must be between 1 and 10 characters long.");
		}
		this.taskID = taskID;
		return true;
	}
	
	// Creating Task class public setter function for the task name
	public boolean setTaskName(String taskName) {
		// Throwing exception if the task name is either null or longer than 20 characters
		if(taskName == null || taskName.length() > 20) {
			throw new IllegalArgumentException("Invalid input! Task name must be between 1 and 20 characters long.");
		}
		this.taskName = taskName;
		return true;
	}
	
	// Creating Task class public setter function for the task description
	public boolean setTaskDescription(String taskDescription) {
		//	Throwing exception if the description is either null or longer than 50 characters
		if(taskDescription == null || taskDescription.length() > 50) {
			throw new IllegalArgumentException("Invalid input! Task description must be between 1 and 50 characters long.");	
		}
		this.taskDescription = taskDescription;
		return true;
	}
	
	//	Creating a private ID constructor to be used in the future
	@SuppressWarnings("unused")
	private Task(String taskID) {
		//	Setting the contact ID		
		setTaskID(taskID);	
	}
	
	//	Creating a public Task constructor
	public Task(String taskID, String taskName, String taskDescription) {
		//	Setting Task class values
		setTaskID(taskID);
		setTaskName(taskName);
		setTaskDescription(taskDescription);
	}
	
	//	Creating a public ID getter function for the Task class
	public String getTaskID() {
		return this.taskID;
	}
	
	//	Creating a public name getter function for the Task class
	public String getTaskName() {
		return this.taskName;	
	}
	
  //	Creating a public description getter function for the Task class
	public String getTaskDescription() {
		return this.taskDescription;
	}
	
	// Not creating an update function for the ID variable per requirements
	
	//	Creating public name update function (setter) for the Task class
	public void updateTaskName(String taskName) {
		setTaskName(taskName);
	}
	
  //	Creating public description update function (setter) for the Task class
	public void updateTaskDescription(String taskDescription) {
		setTaskDescription(taskDescription);
	}
}

