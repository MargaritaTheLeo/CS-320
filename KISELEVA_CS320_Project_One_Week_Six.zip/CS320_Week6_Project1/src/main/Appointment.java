/*                                             *
 * CS-320-R4843 Software Test Automation & QA  *
 * Professor: Angelo Luo                       *
 * Student: Margarita Kiseleva                 *
 * Assignment: 6-1 Project                     *
 * Date: 4/10/2024                             *
 */

// Importing necessary packages and libraries
package main;

import java.util.Date;

// Creating a public appointment class
public class Appointment {
	
	private String appointmentID;
	private Date appointmentDate;
	private String appointmentDescription;

	// creating a boolean validating appointment ID
	private final boolean validateID(String appointmentID) {
		// the boolean returns falls if the ID is either null or longer than 10 characters
		if(appointmentID == null || appointmentID.length() > 10) {
			return false;			
		}		
		// the boolean returns true if the ID satisfies the requirements
		return true;
	}
	
	// creating a boolean validating appointment date
	private final boolean validateDate(Date appointmentDate) {
		// the boolean returns falls if the date is either null or set for the past
		if(appointmentDate == null || appointmentDate.before(new Date())) {
			return false;			
		}
		// the boolean returns true if the date satisfies the requirements
		return true;
	}
	
	// creating a boolean validating appointment description
	private final boolean validateDescription(String appointmentDescription) {
		// the boolean returns falls if the description is either null or longer than 50 characters
		if(appointmentDescription == null || appointmentDescription.length() > 50 || appointmentDescription.equals("")) {	
			return false;			
		}
		// the boolean returns true if the description satisfies the requirements
		return true;
	}
	
	// Creating a public appointment constructor
	public Appointment(String appointmentID, Date appointmentDate, String appointmentDescription) {
		// Throws an exception if ID is invalid
		if(!this.validateID(appointmentID)) {
			throw new IllegalArgumentException("Error - ID is invalid");
		}
		// Throws an exception if date is invalid
		if(!this.validateDate(appointmentDate)) {
			throw new IllegalArgumentException("Error - date is invalid");
		}
		// Throws an exception if description is invalid
		if(!this.validateDescription(appointmentDescription)) {
			throw new IllegalArgumentException("Error - description is invalid");
		}		
		
		// Setters for the appointment's parameters
		setAppointmentID(appointmentID);
		setAppointmentDate(appointmentDate);
		setAppointmentDescription(appointmentDescription);
	}

	// Creating a getter function for appointment's ID
	public int getAppointmentID() {
		return Integer.valueOf(appointmentID);
	}

	// Creating a setter function for appointment's ID
	private void setAppointmentID(String appointmentID){ 
		this.appointmentID = appointmentID; 
	}
	 
	// Creating a getter function for appointment's date
	public Date getAppointmentDate() {
		return appointmentDate;
	}

	// Creating a setter function for appointment's date
	public void setAppointmentDate(Date appointmentDate) {
		// Throw exception if date is invalid
		if(!this.validateDate(appointmentDate)) {
			throw new IllegalArgumentException("Error - date is invalid");
		}
		this.appointmentDate = appointmentDate;
	}
	
	// Creating a getter function for appointment's description
	public String getAppointmentDescription() {
		return appointmentDescription;
	}

	// Creating a setter function for appointment's description
	public void setAppointmentDescription(String appointmentDescription) {
		// Throw exception if description is invalid
		if(!this.validateDescription(appointmentDescription)) {
			throw new IllegalArgumentException("Error - description is invalid");
		}
		this.appointmentDescription = appointmentDescription;
	}
}
