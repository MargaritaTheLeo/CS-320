/*                                             *
 * CS-320-R4843 Software Test Automation & QA  *
 * Professor: Angelo Luo                       *
 * Student: Margarita Kiseleva                 *
 * Assignment: 6-1 Project                     *
 * Date: 4/10/2024                             *
 */

// Importing necessary packages and libraries
package test;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import java.util.Calendar;
import org.junit.jupiter.api.Test;
import main.Appointment;

// Creating a new public appointment test class
class AppointmentTest {

	// Testing creating a new appointment with acceptable parameters
	@Test
	void appointmentTest() {
        String appointmentID = "1";
        Calendar myCalendar = Calendar.getInstance();
        String appointmentDescription = "This is a good description";
        
      	myCalendar.set(Calendar.MONTH, 04);
      	myCalendar.set(Calendar.DATE, 01);
      	myCalendar.set(Calendar.YEAR, 2024);
      	
      	Date goodDate = myCalendar.getTime();
        
        Appointment tempAppt = new Appointment(appointmentID, goodDate, appointmentDescription);
        
        assertEquals(1, tempAppt.getAppointmentID());
        assertEquals(goodDate, tempAppt.getAppointmentDate());
        assertEquals(appointmentDescription, tempAppt.getAppointmentDescription());       
        
	}
	
	// Testing creating an appointment with an ID that is longer than expected
	@Test
	void appointmentIDTooLongTest() {
        String appointmentID = "123456789101112131415";
      	Date appointmentDate = new Date();
        String appointmentDescription = "Good appointment description";
               
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment(appointmentID, appointmentDate, appointmentDescription);
        });
        
        assertEquals("Error - ID is invalid", exception.getMessage());
        
	}
	
	// Testing creating an appointment with a null ID
	@Test
	void appointmentIDNullTest() {
        String appointmentID = null;
      	Date appointmentDate = new Date();
        String appointmentDescription = "Good appointment description";
               
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment(appointmentID, appointmentDate, appointmentDescription);
        });
        
        assertEquals("Error - ID is invalid", exception.getMessage());
        
	}
	
	// Testing creating an appointment with a date set for the past
	@Test
	void appointmentDateInvalidTest() {
        String appointmentID = "1";
        Calendar myCalendar = Calendar.getInstance();
      	String appointmentDescription = "Good appointment description";
      	
      	myCalendar.set(Calendar.MONTH, 04);
      	myCalendar.set(Calendar.DATE, 01);
      	myCalendar.set(Calendar.YEAR, 2000);
      	
      	Date badDate = myCalendar.getTime();
      	              
      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment(appointmentID, badDate, appointmentDescription);
        });
      	
      	assertEquals("Error - date is invalid", exception.getMessage());
        
	}
	
	// Testing creating an appointment with a null date
	@Test
	void appointmentDateNullTest() {
        String appointmentID = "1";
      	String appointmentDescription = "Good appointment description";    	
      	Date badDate = null;
      	
      	Calendar myCalendar = Calendar.getInstance();
      	
      	myCalendar.set(Calendar.MONTH, 04);
      	myCalendar.set(Calendar.DATE, 01);
      	myCalendar.set(Calendar.YEAR, 2024);
      	
      	Date goodDate = myCalendar.getTime();
      	
      	Appointment tempAppt = new Appointment(appointmentID, goodDate, appointmentDescription);      	
      	              
      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment(appointmentID, badDate, appointmentDescription);
        });
      	
      	assertEquals("Error - date is invalid", exception.getMessage());
      	
      	exception = assertThrows(IllegalArgumentException.class, () -> {
        	tempAppt.setAppointmentDate(null);
        });
      	
      	assertEquals("Error - date is invalid", exception.getMessage());
	}
	
	// Testing creating an appointment with a description that is longer than expected
	@Test
	void appointmentDescriptionTooLongTest() {
        String appointmentID = "1";
      	String appointmentDescription = "This description is bad because it is longer than 50 characters, and it will produce an error";    	
      	Calendar myCalendar = Calendar.getInstance();
      	
      	myCalendar.set(Calendar.MONTH, 04);
      	myCalendar.set(Calendar.DATE, 01);
      	myCalendar.set(Calendar.YEAR, 2024);
      	
      	Date goodDate = myCalendar.getTime();
      	
      	
      	Appointment tempAppt = new Appointment(appointmentID, goodDate, "test");
      	              
      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment(appointmentID, goodDate, appointmentDescription);
        });
      	
      	assertEquals("Error - description is invalid", exception.getMessage());
      	
      	exception = assertThrows(IllegalArgumentException.class, () -> {
        	tempAppt.setAppointmentDescription(appointmentDescription);
        });
      	
      	assertEquals("Error - description is invalid", exception.getMessage());
	}
	
	// Testing creating an appointment with a null description
	@Test
	void appointmentDescriptionNullTest() {
        String appointmentID = "1";
      	String appointmentDescription = null;    	
      	Calendar myCalendar = Calendar.getInstance();
      	
      	myCalendar.set(Calendar.MONTH, 04);
      	myCalendar.set(Calendar.DATE, 01);
      	myCalendar.set(Calendar.YEAR, 2024);
      	
      	Date goodDate = myCalendar.getTime();
      	              
      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment(appointmentID, goodDate, appointmentDescription);
        });
      	
      	assertEquals("Error - description is invalid", exception.getMessage());
	}
	
	// Testing creating an appointment with an empty description
	@Test
	void appointmentDescriptionEmptyTest() {
        String appointmentID = "1";
      	String appointmentDescription = "";    	
      	Calendar myCalendar = Calendar.getInstance();
      	
      	myCalendar.set(Calendar.MONTH, 04);
      	myCalendar.set(Calendar.DATE, 01);
      	myCalendar.set(Calendar.YEAR, 2024);
      	
      	Date goodDate = myCalendar.getTime();
      	              
      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment(appointmentID, goodDate, appointmentDescription);
        });
      	
      	assertEquals("Error - description is invalid", exception.getMessage());
	}	
}
