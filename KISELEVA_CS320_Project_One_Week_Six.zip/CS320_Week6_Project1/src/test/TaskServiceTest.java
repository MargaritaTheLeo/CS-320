/*                                             *
 * CS-320-R4843 Software Test Automation & QA  *
 * Professor: Angelo Luo                       *
 * Student: Margarita Kiseleva                 *
 * Assignment: 6-1 Project                     *
 * Date: 4/10/2024                             *
 */

// Importing necessary packages and libraries
package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.NoSuchElementException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import main.Task;
import main.TaskService;

// Declaring a test class for the task service
public class TaskServiceTest {

	//	Creating task objects to be tested
	Task testTaskOne = new Task("1", "My task", "Difficult task");
	Task testTaskWithSameID = new Task("1", "Not my task", "Easy task");
	Task testTaskTwo = new Task("2", "Your task", "Simple task");
	Task testTaskThree = new Task("3", "His task", "Hard task");
	
	//	Creating a task service object to be tested
	TaskService taskService = new TaskService();
	
	//	Testing adding a task
	@Test
	void testAddTask() throws CloneNotSupportedException {
		
		//	Adding a task to the task service
		taskService.addTask(testTaskOne);
		
		//	Testing for the uniqueness of the task ID
		Assertions.assertThrows(CloneNotSupportedException.class, () -> {
			taskService.addTask(testTaskWithSameID);
		});
		
	}
	
	// Testing removing a task
	@Test
	void testRemoveTask() {
		taskService.removeTask("1");
		
		//	Checking whether the task is deleted
		Assertions.assertThrows(NoSuchElementException.class, () -> {
			taskService.updateTaskName("1", "My task");
		});
	}
	
	// Testing updating task name
	@Test
	void testUpdateTaskName() throws Exception {
		//	Adding a new task to the contacts service
		taskService.addTask(testTaskTwo);
		// Checking whether the task name can be updated
		taskService.updateTaskName("2", "Updated task");
		// Accessing the updated task
		Task validateTask = taskService.getTask("2");
		// Making sure the name was updated
		assertTrue(validateTask.getTaskName().equals("Updated task"));
	}
	
	// Testing updating task description
		@Test
		void testUpdateTaskDescription() throws Exception {
			//	Adding a new task to the contacts service
			taskService.addTask(testTaskThree);
			// Checking whether the task name can be updated
			taskService.updateTaskDescription("3", "Not a hard task");
			// Accessing the updated task
			Task validateTask = taskService.getTask("3");
			// Making sure the name was updated
			assertTrue(validateTask.getTaskDescription().equals("Not a hard task"));
		}

	// Testing updating nonexistent task name
		@Test
		void testUpdateNonexistentTaskName() throws NoSuchElementException {
			Assertions.assertThrows(NoSuchElementException.class, () -> {
			taskService.updateTaskName("4", "Nonexistent task name");
			});
		}
		
	// Testing updating nonexistent task description
		@Test
		void testUpdateNonexistentTaskDescription() throws NoSuchElementException {
			Assertions.assertThrows(NoSuchElementException.class, () -> {
			taskService.updateTaskDescription("4", "Nonexistent task description");
			});
		}
}


