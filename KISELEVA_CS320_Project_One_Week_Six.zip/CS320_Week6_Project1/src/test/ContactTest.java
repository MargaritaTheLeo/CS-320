/*                                             *
 * CS-320-R4843 Software Test Automation & QA  *
 * Professor: Angelo Luo                       *
 * Student: Margarita Kiseleva                 *
 * Assignment: 6-1 Project                     *
 * Date: 4/10/2024                             *
 */

// Importing necessary packages and libraries
package test;

// Importing needed packages
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import main.Contact;

class ContactTest {
    // Testing contactID argument's length
    @Test
    void contactIDTooLongTest() {
        Assertions.assertThrows(IllegalArgumentException.class,
                ()->{
                    new Contact( "00000000000", "Mauricio", "DiMauro", "9999999999",
                            "0 Wunschpunsch Rd");
                });
    }
    // Testing whether contactID argument is null
    @Test
    void testContactIDNull() {
        Assertions.assertThrows(IllegalArgumentException.class,
                ()->{
                    new Contact( null, "Mauricio", "DiMauro", "9999999999",
                            "0 Wunschpunsch Rd");
                });
    }

    // Testing firstName argument's length 
    @Test
    void firstNameTooLongTest() {
        Assertions.assertThrows(IllegalArgumentException.class,
                ()->{
                    new Contact( "0", "MauricioMauricio", "DiMauro", "9999999999",
                            "0 Wunschpunsch Rd");
                });
    }
    // Testing whether firstName argument is null
    @Test
    void firstNameNullTest() {
        Assertions.assertThrows(IllegalArgumentException.class,
                ()->{
                    new Contact( "0", null, "DiMauro", "9999999999",
                            "0 Wunschpunsch Rd");
                });
    }

    // Testing updateFirstName method
    @Test
    void firstNameUpdateTest() throws Exception{
        Contact contact = new Contact ( "0", "Mauricio", "DiMauro", "9999999999",
                "0 Wunschpunsch Rd");
        contact.updateFirstName("Mario");
        assertAll(
                "first name",
                ()
                        -> assertEquals("Mario", contact.getFirstName()),
                ()
                        -> assertThrows(IllegalArgumentException.class,
                        ()-> contact.updateFirstName(null)),
                ()
                        -> assertThrows(IllegalArgumentException.class,
                        ()-> contact.updateFirstName("MauricioDiMauro"))
        );
    }

    // Testing whether last name is too long
    @Test
    void lastNameTooLongTest() {
        Assertions.assertThrows(IllegalArgumentException.class,
                ()->{
                    new Contact( "0", "Mauricio", "DiMauroDiMauro", "9999999999",
                            "0 Wunschpunsch Rd");
                });
    }
    
    // Testing whether last name is null
    @Test
    void lasttNameNullTest() {
        Assertions.assertThrows(IllegalArgumentException.class,
                ()->{
                    new Contact( "0", "Mauricio", null, "9999999999",
                            "0 Wunschpunsch Rd");
                });
    }

    // Testing updateLastName method
    @Test
    void lastNameUpdateTest() throws Exception{
        Contact contact = new Contact ( "0", "Mauricio", "DiMauro", "9999999999",
                "0 Wunschpunsch Rd");
        contact.updateLastName("Coppola");
        assertAll(
                "last name",
                ()
                        -> assertEquals("Coppola", contact.getLastName()),
                ()
                        -> assertThrows(IllegalArgumentException.class,
                        ()-> contact.updateLastName(null)),
                ()
                        -> assertThrows(IllegalArgumentException.class,
                        ()-> contact.updateLastName("MauricioDiMauro"))
        );
    }

    // Testing whether the phone number is too long or too short
    @Test
    void phoneTooLongTest() {
        Assertions.assertThrows(IllegalArgumentException.class,
                ()->{
                    new Contact( "0", "Mauricio", "DiMauro", "99999999999",
                            "0 Wunschpunsch Rd");
                });
    }
    
    // Testing whether the phone number is null
    @Test
    void phoneNullTest() {
        Assertions.assertThrows(IllegalArgumentException.class,
                ()->{
                    new Contact( "0", "Mauricio", "DiMauro", null,
                            "0 Wunschpunsch Rd");
                });
    }

    // Testing updatePhone method
    @Test
    void phoneUpdateTest(){
        Contact contact = new Contact ( "0", "Mauricio", "DiMauro", "9999999999",
                "0 Wunschpunsch Rd");
        contact.updatePhoneNumber("1111111111");
        assertAll(
                "phone number",
                ()
                        -> assertEquals("1111111111", contact.getPhoneNumber()),
                ()
                        -> assertThrows(IllegalArgumentException.class,
                        ()-> contact.updatePhoneNumber(null)),
                ()
                        -> assertThrows(IllegalArgumentException.class,
                        ()-> contact.updatePhoneNumber("111111111"))
        );

    }

    // Testing whether the address is too long
    @Test
    void addressTooLongTest() {
        Assertions.assertThrows(IllegalArgumentException.class,
                ()->{
                    new Contact( "0", "Mauricio", "DiMauro", "9999999999",
                            "000000000000000000000000 Wunschpunsch Rd");
                });
    }

    // Testing whether the address is null
    @Test
    void addressNullTest() {
        Assertions.assertThrows(IllegalArgumentException.class,
                ()->{
                    new Contact( "0", "Mauricio", "DiMauro", "9999999999",
                            null);
                });
    }
    
    // Testing updateAddress method
    @Test 
    void addressUpdateTest(){
        Contact contact = new Contact ( "0", "Mauricio", "DiMauro", "9999999999",
                "0 Wunschpunsch Rd");
        contact.updateAddress ("100 Wunschpunsch Rd");
        assertAll(
                "address",
                ()
                        -> assertEquals("100 Wunschpunsch Rd", contact.getAddress()),
                ()
                        -> assertThrows(IllegalArgumentException.class,
                        ()-> contact.updateAddress(null)),
                ()
                        -> assertThrows(IllegalArgumentException.class,
                        ()-> contact.updateAddress("000000000000000000000000 Wunschpunsch Rd"))
        );

    }

}

