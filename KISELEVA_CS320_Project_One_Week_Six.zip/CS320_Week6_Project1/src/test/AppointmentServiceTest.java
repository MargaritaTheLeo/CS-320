/*                                             *
 * CS-320-R4843 Software Test Automation & QA  *
 * Professor: Angelo Luo                       *
 * Student: Margarita Kiseleva                 *
 * Assignment: 6-1 Project                     *
 * Date: 4/10/2024                             *
 */

// Importing necessary packages and libraries
package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import main.AppointmentService;
import static org.junit.Assert.assertEquals;
import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.AfterEach;

// Creating a new public appointment service class
class AppointmentServiceTest {
	
	// Clearing the list of appointments after each test execution
	@AfterEach
	void tearDown() throws Exception {
		AppointmentService.appointments.clear();
	}

	// Testing adding an appointment with acceptable parameters to the list
	@Test
	void addUniqueAppointmentTest() {
		String id = "0";
		String appointmentDescription = "Good appointment description";
		
		Calendar myCalendar = Calendar.getInstance();
		myCalendar.set(Calendar.MONTH, 04);
		myCalendar.set(Calendar.DATE, 01);
		myCalendar.set(Calendar.YEAR, 2024);

		Date goodDate = myCalendar.getTime();

		AppointmentService tempAppt = new AppointmentService();

		assertEquals(0, AppointmentService.appointments.size());

		tempAppt.addUniqueAppointment(goodDate, appointmentDescription);

		assertTrue(AppointmentService.appointments.containsKey(id));
		assertEquals(goodDate, AppointmentService.appointments.get(id).getAppointmentDate());
		assertEquals(appointmentDescription, AppointmentService.appointments.get(id).getAppointmentDescription());

	}
	
	// Testing adding an appointment with an empty description to the list
	@Test
	void addEmptyDescriptionTest() {
		String appointmentID = "0";
		String appointmentDescription = ""; //bad description
		
		Calendar myCalendar = Calendar.getInstance();
		myCalendar.set(Calendar.MONTH, 04);
		myCalendar.set(Calendar.DATE, 01);
		myCalendar.set(Calendar.YEAR, 2024);

		Date goodDate = myCalendar.getTime();

      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
      		AppointmentService tempAppt = new AppointmentService();
      		tempAppt.addUniqueAppointment(goodDate, appointmentDescription);
        });
      	
      	assertEquals("Error - description is invalid", exception.getMessage());

	}
	
	// Testing adding an appointment with a null description to the list
	@Test
	void addNullDescriptionTest() {
		String appointmentID = "0";
		String appointmentDescription = null; //bad description
		
		Calendar myCalendar = Calendar.getInstance();
		myCalendar.set(Calendar.MONTH, 04);
		myCalendar.set(Calendar.DATE, 01);
		myCalendar.set(Calendar.YEAR, 2024);

		Date goodDate = myCalendar.getTime();

      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
      		AppointmentService tempAppt = new AppointmentService();
      		tempAppt.addUniqueAppointment(goodDate, appointmentDescription);
        });
      	
      	assertEquals("Error - description is invalid", exception.getMessage());

	}

	// // Testing removing an appointment from the list
	@Test
	void removeAppointmentTest() {
		String appointmentID = "0";
		String appointmentDescription = "Good appointment description";
		
		Calendar myCalendar = Calendar.getInstance();
		myCalendar.set(Calendar.MONTH, 04);
		myCalendar.set(Calendar.DATE, 01);
		myCalendar.set(Calendar.YEAR, 2024);

		Date goodDate = myCalendar.getTime();

		AppointmentService tempAppt = new AppointmentService();

		assertEquals(0, AppointmentService.appointments.size());

		tempAppt.addUniqueAppointment(goodDate, appointmentDescription); // obj 0
		tempAppt.addUniqueAppointment(goodDate, appointmentDescription); // obj 1
		tempAppt.addUniqueAppointment(goodDate, appointmentDescription); // obj 2

		assertEquals(3, AppointmentService.appointments.size());

		tempAppt.deleteAppointment("1");

		assertEquals(2, AppointmentService.appointments.size());
		assertFalse(AppointmentService.appointments.containsKey("1"));
		
		tempAppt.deleteAppointment("1");
		assertEquals(2, AppointmentService.appointments.size());

	}
	
	
	// Testing creating an appointment and updating its description
	 @Test 
	 void updateAppointmentTest() { 
		 String appointmentID = "0"; 
		 String description = "Good appointment description"; 
		 
		 Calendar myCalendar = Calendar.getInstance();
		 myCalendar.set(Calendar.MONTH, 04);
		 myCalendar.set(Calendar.DATE, 01);
		 myCalendar.set(Calendar.YEAR, 2024);
		 
		 Date goodDate = myCalendar.getTime();
		 
		 AppointmentService tempAppt = new AppointmentService();
		 tempAppt.addUniqueAppointment(goodDate, description); //obj 0
		 tempAppt.updateAppointment("0", goodDate, "New appointment description");
		 
		 assertEquals("New appointment description", AppointmentService.appointments.get(appointmentID).getAppointmentDescription());
		 assertEquals(goodDate, AppointmentService.appointments.get(appointmentID).getAppointmentDate()); 
	 }

	 
	 // Testing updating description for the appointment that does not exist
	 @Test 
	 void updateAppointmentBadIDTest() { 
		 String appointmentID = "0"; 
		 String description = "Good appointment description"; 
		 
		 Calendar myCalendar = Calendar.getInstance();
		 myCalendar.set(Calendar.MONTH, 04);
		 myCalendar.set(Calendar.DATE, 01);
		 myCalendar.set(Calendar.YEAR, 2024);
		 
		 Date goodDate = myCalendar.getTime();
		 
		 AppointmentService tempAppt = new AppointmentService();
		 tempAppt.addUniqueAppointment(goodDate, description); // obj 0
		 tempAppt.updateAppointment("1", goodDate, "New appointment description"); // bad ID
		 
		 assertNotEquals("New description", AppointmentService.appointments.get(appointmentID).getAppointmentDescription());
		 assertEquals(goodDate, AppointmentService.appointments.get(appointmentID).getAppointmentDate());
	 } 
}
