/*                                             *
 * CS-320-R4843 Software Test Automation & QA  *
 * Professor: Angelo Luo                       *
 * Student: Margarita Kiseleva                 *
 * Assignment: 6-1 Project                     *
 * Date: 4/10/2024                             *
 */

// Importing necessary packages and libraries
package test;

// Importing packages necessary for testing
import static org.junit.jupiter.api.Assertions.assertTrue;
import java.util.NoSuchElementException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import main.Contact;
import main.ContactService;

// Declaring a test class for the contact service
public class ContactServiceTest {

	//	Creating contact objects to be tested
	Contact testContact1 = new Contact("1", "Mauricio", "DiMauro", "9999999999", "1 Wunschpunsch Rd");
	Contact testContactWithSameID = new Contact("1", "Mauricia", "DiMauro", "8888888888", "1 Wunschpunsch Rd");
	Contact testContact2 = new Contact("2", "Jacob", "Scribble", "7777777777", "2 Wunschpunsch Rd");
	
	//	Creating contact service to be tested
	ContactService contactService = new ContactService();
	
	//	Creating a test class for the contact service
	@Test
	void addContactTest() throws CloneNotSupportedException {
		
		//	Adding a contact to the contacts service
		contactService.addContact(testContact1);
		
		//	Testing for the uniqueness of the contact ID
		Assertions.assertThrows(CloneNotSupportedException.class, () -> {
			contactService.addContact(testContactWithSameID);
		});
		
	}
	
	@Test
	void removeContactTest() {
		//	Testing the removal of a contact
		contactService.removeContact("1");
		
		//	Checking whether the contact is deleted
		Assertions.assertThrows(NoSuchElementException.class, () -> {
			contactService.updateFirstName("1", "Mauricia");
		});
	}

	@Test
	void updateContactTest() throws Exception {
		
		//	Adding a new contact to the contacts service
		contactService.addContact(testContact2);
		
		// Checking whether the contact can be updated
		contactService.updateFirstName("2", "Maledictus");
		contactService.updateLastName("2", "Maggot");
		contactService.updatePhoneNumber("2", "5555555555");
		contactService.updateAddress("2", "4 Wunschpunsch Rd");
		
		Contact validateContact = contactService.getContact("2");
		
		assertTrue(validateContact.getFirstName().equals("Maledictus"));
		assertTrue(validateContact.getLastName().equals("Maggot"));
		assertTrue(validateContact.getPhoneNumber().equals("5555555555"));
		assertTrue(validateContact.getAddress().equals("4 Wunschpunsch Rd"));
	}

	@Test
	void updateNonExistentContactTest() throws NoSuchElementException {
	
		// Checking whether it is possible to update first name of a nonexistent contact
		Assertions.assertThrows(NoSuchElementException.class, () -> {
			contactService.updateFirstName("3", "Bubonic");
		});
		
		// Checking whether it is possible to update last name of a nonexistent contact
		Assertions.assertThrows(NoSuchElementException.class, () -> {
			contactService.updateLastName("3", "Prepostero");
		});
		
		// Checking whether it is possible to update phone number of a nonexistent contact
		Assertions.assertThrows(NoSuchElementException.class, () -> {
			contactService.updatePhoneNumber("3", "7777777777");
		});
		
		// Checking whether it is possible to update address of a nonexistent contact
		Assertions.assertThrows(NoSuchElementException.class, () -> {
			contactService.updateAddress("3", "2 Wunschpunsch Rd");
		});
	}	
}

