/*                                             *
 * CS-320-R4843 Software Test Automation & QA  *
 * Professor: Angelo Luo                       *
 * Student: Margarita Kiseleva                 *
 * Assignment: 6-1 Project                     *
 * Date: 4/10/2024                             *
 */

// Importing necessary packages and libraries
package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import main.Task;

class TaskTest {

	// Testing task ID argument length
    @Test
    void testTaskIDTooLong() {
        Assertions.assertThrows(IllegalArgumentException.class,
                ()->{
                    new Task( "00123456789 Too long", "My task 1", "Easy task");
                });
    }
    
    // Testing whether task ID argument is null
    @Test
    void testTaskIDNull() {
        Assertions.assertThrows(IllegalArgumentException.class,
                ()->{
                    new Task( null, "My task 1", "Easy task");
                });
    }

    // Testing task name argument length 
    @Test
    void testTaskNameTooLong() {
        Assertions.assertThrows(IllegalArgumentException.class,
                ()->{
                    new Task( "12345", "My task name is too long 12345678910", "Easy task");
                });
    }
    
    // Testing whether task name argument is null
    @Test
    void testTaskNameNull() {
        Assertions.assertThrows(IllegalArgumentException.class,
                ()->{
                    new Task( "12345", null, "Easy task");
                });
    }

    // Testing update task name method
    @Test
    void testUpdateTaskName() throws Exception{
        Task task = new Task ( "12345", "My task", "Easy task");
        task.updateTaskName("Your task");
        assertAll(
                ()
                        -> assertEquals("Your task", task.getTaskName()),
                ()
                        -> assertThrows(IllegalArgumentException.class,
                        ()-> task.updateTaskName(null)),
                ()
                        -> assertThrows(IllegalArgumentException.class,
                        ()-> task.updateTaskName("My task name is too long 12345678910"))
                        
        );
    }

    // Testing whether task description is too long
    @Test
    void testTaskDescriptionTooLong() {
        Assertions.assertThrows(IllegalArgumentException.class,
                ()->{
                    new Task( "12345", "My task", "Difficult task description is too long 123456789012345678901234567890");
                });
    }
    
    // Testing whether task description is null
    @Test
    void testTaskDescriptionNull() {
        Assertions.assertThrows(IllegalArgumentException.class,
                ()->{
                    new Task( "12345", "My task", null);
                });
    }

    // Testing update task description method
    @Test
    void testUpdateTaskDescription() throws Exception{
        Task task = new Task ( "12345", "My task", "Easy task");
        task.updateTaskDescription("Difficult task");
        assertAll(		
                ()
                        -> assertEquals("Difficult task", task.getTaskDescription()),
                ()
                        -> assertThrows(IllegalArgumentException.class,
                        ()-> task.updateTaskDescription(null)),
                ()
                        -> assertThrows(IllegalArgumentException.class,
                        ()-> task.updateTaskDescription("Difficult task description is too long 123456789012345678901234567890"))                
        );
    } 
}


